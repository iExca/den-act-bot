/*
	Bot teams
*/

exports.teams = {
	//Example: "tier": ['team1', 'team2']
};
