Bot Features
====================

Each directory is a feature. In order to add features, create folder with an `index.js` main file. To remove them just delete the folders.
